﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilRouge.Metiers.ClassesMetiers
{
    public class Adresse
    {


        protected string nomRue;
        protected string codePostal;
        protected string ville;
        protected string pays;


       





        public int AdresseId
        {
            get;
            set;
        }
        public string NomDeRue
        {
            get { return nomRue; }
            set { nomRue = value; }
        }

        public string CodePostal
        {
            get { return codePostal; }
            set { codePostal = value; }
        }
        public string Ville
        {
            get { return ville; }
            set { ville = value; }
        }
        public string Pays
        {
            get { return pays; }
            set { pays = value; }
        }
    


        public  virtual ICollection<Utilisateur> Utilisateurs { get; set; }



       

        //public Adresse()
        //{

        //}
    }



}
