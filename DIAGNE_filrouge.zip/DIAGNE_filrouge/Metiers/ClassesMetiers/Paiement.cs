﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilRouge.Metiers.ClassesMetiers
{
    public class Paiement
    {

        private int numeroPaiement;

        public int PaiementId { get; set; }
        public int UtilisateurId { get; set; }
        public virtual Client  Client { get; set; }

        public int NumeroPaiement
        {

            get { return numeroPaiement; }
            set { numeroPaiement= value; }
        }

    }
}
