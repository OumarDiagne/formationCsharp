﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilRouge.Metiers.ClassesMetiers
{ 
   public class Commande                  //  1 vers 1
    {
        private double facture;

        public int CommandeId { get; set; }    
        public int UtilisateurId { get; set; }
        public virtual Client Clients { get; set; }

        public double Facture
        {
            get { return facture; }
            set { facture = value; }
        }

        // public Enum EtatCommande { get; set; }

        public Commande(double facture)
        {
            this.facture = facture;
        }

    }
}
