﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilRouge.Metiers.ClassesMetiers
{
    public class Administrateur : Utilisateur
    {



        //public Administrateur(string nom, string prenom, string identifiant, string password)
        //    : base(nom, prenom, identifiant, password)
        //{
        //    this.nom = nom;
        //    this.prenom = prenom;
        //    this.identifiant = identifiant;
        //    this.password = password;
        //}

        //methode gestion role   a la fin de la creation  






        //methode gestion promotion



        //methode actualisation catalogue






    }
}
