﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilRouge.Metiers.ClassesMetiers
{
    public class Produit                     // * vers 1 , catalogue
    {

        private string nom;
        private decimal prix;
        private string refProduit;

        //accesseurs
        public int ProduitId { get; set; }
        public string Nom
        {
            get { return nom; }
            set { nom = value; }
        }
        public decimal Prix
        {
            get { return prix; }
            set { prix = value; }
        }
        public string RefProduit
        {
            get { return refProduit; }
            set { refProduit = value; }
        }

        //declaration pour la relation many to 1, * vers 1
        public int CatalogueId { get; set; }
        public virtual Catalogue Catalogue { get; set; }

        public int PromotionId { get; set; }
        public virtual Promotion Promotion { get; set; }

        //declaration pour les 2 relation many to many, * vers * avec client       
        public virtual ICollection<ProduitsConsulte> ProduitsConsulte { get; set; }
        public virtual ICollection<AvisProduit> ProduitsAvis { get; set; }

    }
}
