﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FilRouge.Metiers.ClassesMetiers;
using FilRouge.Dao;
using FilRouge.Metiers.ClassesModeles;

namespace FilRouge.Metiers.InterfacesMetiers
{
    public class MetersImpAdmin : ImetiersAdmin
    {


        public IDao implemente = new DaoImp();

        //methode admin deja implementés en bdd

        public Role AjouterUnRole(Role unRole)
        {
            return implemente.AjouterUnRole(unRole);
        }

        //public ICollection<Client> FindAllClient()
        //{
        //    return implemente.FindAllClient();
        //}

        

        public Utilisateur AjouterUnClient(Client monClient)
        {

            return implemente.AjouterUnClient(monClient);

        }

        public ICollection<Role> findAllRole()
        {
            return implemente.findAllRole();
        }

        public Role findRole(int id)
        {
            return implemente.findRole(id);
        }

        public void ModifierUnRole(Role unRole)
        {
            implemente.ModifierUnRole(unRole);
        }

        public void SupprimerUnRole(int idRole)
        {
            implemente.SupprimerUnRole(idRole);
        }
        public ICollection<Role> findRoleById(int id)
        {
            return implemente.findRoleById(id);
        }
        public Adresse findAdresse(int id)
        {
            return implemente.findAdresse(id);
        }

        public void ModifierUneAdresse(Adresse monAdresse)
        {
            implemente.ModifierUneAdresse(monAdresse);
        }

        public void SupprimerUneAdresse(int monAdresse)
        {
            implemente.SupprimerUneAdresse(monAdresse);
        }

        public ICollection<Adresse> findAllAdresse()
        {
            return implemente.findAllAdresse();
        }

        public ICollection<Adresse> findAdresseById(int id)
        {
            return implemente.findAdresseById(id);
        }
        public Adresse AjouterUneAdresse(Adresse monAdresse)
        {
            return implemente.AjouterUneAdresse(monAdresse);
        }

        public ICollection<Utilisateur> findAllAdministrateurs()
        {
            return implemente.findAllAdministrateurs();
        }

        public Utilisateur AjouterUnAdministrateur(Administrateur monAdmin)
        {
            return implemente.AjouterUnAdministrateur(monAdmin);
        }

        public Utilisateur findAdministrateur(int id)
        {
            return implemente.findAdministrateur(id);
        }

        public void ModifierUnAdministrateur(Administrateur monAdmin)
        {
            implemente.ModifierUnAdministrateur(monAdmin);
        }

        public ICollection<Utilisateur> findAdministrateurById(int id)
        {
            return implemente.findAdministrateurById(id);
        }

        public void SupprimerUnAdministrateur(int monAdmin)
        {
            implemente.SupprimerUnAdministrateur(monAdmin);
        }

        public ICollection<AdministrateurModele> findAllAdministrateurModele()
        {
            return implemente.findAllAdministrateurModele();
        }
        public Administrateur LoginAdmin(Administrateur a)
        {
            return implemente.LoginAdmin(a);
        }

        public ICollection<ClientModele> findAllClientModele()
        {
            return implemente.findAllClientModele();
        }


        public Client LoginClient(Client c)
        {
            return implemente.LoginClient(c);
        }

        public Utilisateur findClient(int id)
        {
            return implemente.findClient(id);
        }


        public void ModifierUnClient(Client unClient)
        {
            implemente.ModifierUnClient(unClient);
        }

        public ICollection<Client> findAllClient()
        {
            return implemente.findAllClient();
        }

        public ICollection<Utilisateur> findClientById(int id)
        {
            return implemente.findClientById(id);
        }

        public void SupprimerUnClient(int monClient)
        {
            implemente.SupprimerUnClient(monClient);
        }

        public Produit AjouterUnProduit(Produit monProduit)
        {
            return implemente.AjouterUnProduit(monProduit);
        }

        public ICollection<Produit> findAll()
        {
            return implemente.findAll();
        }

        public Produit findProduit(int Idproduit)
        {
            return implemente.findProduit(Idproduit);
        }

        public void SupprimerUnProduit(int Idproduit)
        {
                implemente.SupprimerUnProduit(Idproduit);
        }

        public void ModifierUnProduit(Produit monProduit)
        {
            implemente.ModifierUnProduit(monProduit);
        }

        public ICollection<Produit> findProductByName(string nom)
        {
            return implemente.findProductByName(nom);
        }

        /*******************************************************************************************************/



        public void AfficheAllUser(ICollection<Utilisateur> userAllAAfficher)
        {
            throw new NotImplementedException();
        }


        public Catalogue AjouterCatalogue(Catalogue monCatalogue)
        {
            throw new NotImplementedException();
        }

      

        public Promotion AjouterUnePromotion(Promotion maPromo)
        {
            throw new NotImplementedException();
        }


      

        public Catalogue MAJCatalogue(Catalogue monCatalogue)
        {
            throw new NotImplementedException();
        }

       
        

       

        public Produit ModifierProduit(Produit monProduit)
        {
            throw new NotImplementedException();
        }

        public Promotion ModifierUnePromotion(Promotion maPromo)
        {
            throw new NotImplementedException();
        }

      

       

       

        public BonDeLivraison SupprimerBonLivr(BonDeLivraison monBonDeLivr)
        {
            throw new NotImplementedException();
        }

        public Catalogue SupprimerCatalogue(Catalogue monCatalogue)
        {
            throw new NotImplementedException();
        }

       

        public Commande SupprimerCommande(Commande maCommande)
        {
            throw new NotImplementedException();
        }

        public Produit SupprimerProduit(Produit monProduit)
        {
            throw new NotImplementedException();
        }

        public Promotion SupprimerUnePromotion(Promotion maPromo)
        {
            throw new NotImplementedException();
        }

   
    }
}
