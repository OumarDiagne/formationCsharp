﻿using FilRouge.Metiers.ClassesMetiers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FilRouge.Metiers.ClassesModeles
{
    public class ProduitCataModele
    {
        public int ProduitCataModeleId { get; set; }
        public string Nom { get; set; }
        public decimal Prix { get; set; }
        public string RefProduit { get; set; }
        public virtual ICollection<Catalogue> MonCatalogue { get; set; }
    }
}