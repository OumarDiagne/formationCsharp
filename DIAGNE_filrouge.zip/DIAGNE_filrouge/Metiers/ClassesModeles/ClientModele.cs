﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FilRouge.Metiers.ClassesModeles
{
    public class ClientModele
    {
        public int ClientModeleId { get; set; }
        public string Nom { get; set; }
        public string Prenom { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string Identifiant { get; set; }
        public string Password { get; set; }
        public string MdpConfirm { get; set; }
        public string Email { get; set; }
        public int Droit { get; set; }
        public string NomDeRue { get; set; }
        public string CodePostal { get; set; }
        public string Ville { get; set; }
        public string Pays { get; set; }   
        public DateTime DateStartTime { get; set; }  
        public Boolean Anniversaire { get; set; }
        public string NumeroCarteFidelite { get; set; }
        public int NbPoints { get; set; }
        public bool CompteActif { get; set; }
        public bool CompteASupprimer { get; set; }
    }
}