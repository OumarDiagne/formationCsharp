﻿using FilRouge.Metiers.ClassesMetiers;
using FilRouge.Metiers.ClassesModeles;
using FilRouge.Metiers.InterfacesMetiers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FilRouge.Controllers
{
    public class ClientController : Controller
    {
        // GET: Client
        public ImetiersAdmin Imetiers = new MetersImpAdmin();


        public ActionResult Login()
        {
            return View();
        }





        [HttpPost]
        public ActionResult Login(Client c)
        {
            //if(ModelState.IsValid)
            //{
            var monUser = Imetiers.LoginClient(c);
            if (monUser != null)
            {
                Session["UtilisateurId"] = monUser.UtilisateurId;
                Session["Nom"] = monUser.Nom;
                Session["Prenom"] = monUser.Prenom;
                Session["RoleId"] = monUser.RoleId;
                TempData["RoleClient"] = monUser.RoleId;
                return RedirectToAction("LoggedIn");

            }
            else
            {
                ModelState.AddModelError("", "user ou password incorrect");
                return View();
            }

        }
        public ActionResult Index()
        {

            if (Session["UtilisateurId"] != null)
            {
                ICollection<ClientModele> res = Imetiers.findAllClientModele();
                return View(res);
            }
            else
                return View("Login");



        }

        // vue d' affichage du formulaire d'ajout des roles
        public ActionResult AjouterUnClient()
        {
            
                return View();
           
        }

        [HttpPost]
        public ActionResult AjouterUnClient(Client c)
        {
            if (ModelState.IsValid)
            {
                Imetiers.AjouterUnClient(c);
                return RedirectToAction("Index");
            }

            else
            {
                return View(c);
            }
        }

        public ActionResult ModifierUnClient(int id)
        {

            if (Session["RoleAdmin"] != null || Session["RoleClient"] != null)
            {

                Utilisateur monAdmin = Imetiers.findClient(id);

                return View(monAdmin);
            }
            else
                return View("Login");
        }

        [HttpPost]
        public ActionResult ModifierUnClient(Client c)
        {

            Imetiers.ModifierUnClient(c);

            //a chaque fois qu on ajoute une categorie on la redirige vers l'action qui liste les elements
            return RedirectToAction("Index");
        }


        public ActionResult RechercherUnClient()
        {

            if (Session["RoleAdmin"] != null)
            {
                ICollection<Client> users = Imetiers.findAllClient();
                return View(users);

            }
            else
                return View("Login");

        }

        [HttpPost]
        public ActionResult RechercherUnClient(int ClientId)
        {

            ICollection<Utilisateur> product = Imetiers.findClientById(ClientId);

            //a chaque fois qu on ajoute une categorie on la redirige vers l'action qui liste les elements
            return View(product);
        }

        public ActionResult SupprimerUnClient(int id)
        {
            if (Session["RoleAdmin"] != null || Session["RoleClient"] != null)
            {
                Imetiers.SupprimerUnClient(id);
                return RedirectToAction("Index");
            }
            else
                return View("Login");
        }





        public ActionResult LoggedIn()
        {

            int role = (int)Session["RoleId"];
            if (role == (int)TempData["RoleClient"])
            {
                return View();
            }
            else
            {
                return RedirectToAction("Login");
            }

        }


        public ActionResult Logout()
        {
            Session["UtilisateurId"] = null;
            Session["Nom"] = null;
            Session["Prenom"] = null;
            Session["RoleId"] = null;
            return RedirectToAction("Login");
        }
    }
}