﻿using FilRouge.Metiers.ClassesMetiers;
using FilRouge.Metiers.InterfacesMetiers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FilRouge.Controllers
{
    public class AdresseController : Controller
    {
        public IMetiersUsers Imetier = new MetiersImpUsers();
        public ImetiersAdmin Imetiers = new MetersImpAdmin();

        /********************************************************************************************************************/
        /**************************** methode de l administrateur            **********************/
        // GET: Adresse

        //
        public ActionResult Index()
        {
            ICollection<Adresse> res = Imetiers.findAllAdresse();
            return View(res);
        }

        // vue d' affichage du formulaire d'ajout d'adresse pour l'administrateur
        public ActionResult AjouterUneAdresse()
        {
            return View();
        }

        [HttpPost]
        public ActionResult AjouterUneAdresse(Adresse monAdresse)
        {
            if (ModelState.IsValid)
            {
                Imetiers.AjouterUneAdresse(monAdresse);
                return RedirectToAction("index");
            }

            else
            {
                return View(monAdresse);
            }
        }

        public ActionResult ModifierUneAdresse(int id)
        {

            Adresse monAdresse = Imetiers.findAdresse(id);

            return View(monAdresse);
        }

        [HttpPost]
        public ActionResult ModifierUneAdresse(Adresse a)
        {

            Imetiers.ModifierUneAdresse(a);

            //a chaque fois qu on ajoute une categorie on la redirige vers l'action qui liste les elements
            return RedirectToAction("Index");
        }


        public ActionResult RechercherUneAdresse()
        {
            ICollection<Adresse> product = Imetiers.findAllAdresse();
            return View(product);

        }

        [HttpPost]
        public ActionResult RechercherUneAdresse(int AdresseId)
        {

            ICollection<Adresse> product = Imetiers.findAdresseById(AdresseId);

            //a chaque fois qu on ajoute une categorie on la redirige vers l'action qui liste les elements
            return View(product);
        }

        public ActionResult SupprimerUneAdresse(int id)
        {
            Imetiers.SupprimerUneAdresse(id);
            return RedirectToAction("Index");
        }
    }
}