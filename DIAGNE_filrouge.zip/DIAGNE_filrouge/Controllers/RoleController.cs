﻿using FilRouge.Metiers.ClassesMetiers;
using FilRouge.Metiers.InterfacesMetiers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FilRouge.Controllers
{
    public class RoleController : Controller
    {
        public ImetiersAdmin Imetiers = new MetersImpAdmin();


        // GET: Role

        //liste les roles ajoutés en base de données
        public ActionResult Index()
        {
            ICollection<Role> res = Imetiers.findAllRole();
            return View(res);
        }

        // vue d' affichage du formulaire d'ajout des roles
        public ActionResult AjouterUnRole()
        {
            return View();
        }

        [HttpPost]
        public ActionResult AjouterUnRole(Role unRole)
        {
            if (ModelState.IsValid)
            {
                Imetiers.AjouterUnRole(unRole);
                return RedirectToAction("Index");
            }

            else
            {
                return View(unRole);
            }
        }

        public ActionResult ModifierUnRole(int id)
        {

            Role monRole = Imetiers.findRole(id);
           
            return View(monRole);
        }

        [HttpPost]
        public ActionResult ModifierUnRole(Role r)
        {

            Imetiers.ModifierUnRole(r);

            //a chaque fois qu on ajoute une categorie on la redirige vers l'action qui liste les elements
            return RedirectToAction("Index");
        }


        public ActionResult RechercherUnRole()
        {
            ICollection<Role> product = Imetiers.findAllRole();
            return View(product);

        }

        [HttpPost]
        public ActionResult RechercherUnRole(int RoleId)
        {

            ICollection<Role> product = Imetiers.findRoleById(RoleId);

            //a chaque fois qu on ajoute une categorie on la redirige vers l'action qui liste les elements
            return View(product);
        }

        public ActionResult SupprimerUnRole(int id)
        {
            Imetiers.SupprimerUnRole(id);
            return RedirectToAction("Index");
        }
    }
}