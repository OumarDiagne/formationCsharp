﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FilRouge.Controllers
{
    public class PaiementController : Controller
    {
        // GET: Paiement
        public ActionResult Index()
        {
            return View();
        }
    }
}