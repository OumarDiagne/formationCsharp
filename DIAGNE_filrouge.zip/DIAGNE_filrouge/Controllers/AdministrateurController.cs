﻿using FilRouge.Metiers.InterfacesMetiers;
using FilRouge.Metiers.ClassesMetiers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FilRouge.Metiers.ClassesModeles;

namespace FilRouge.Controllers
{
    public class AdministrateurController : Controller
    {

        public ImetiersAdmin Imetiers = new MetersImpAdmin();
        // GET: Administrateur

        public ActionResult Login()
        {
            return View();
        }





        [HttpPost]
        public ActionResult Login(Administrateur a)
        {
            //if(ModelState.IsValid)
            //{
            var monUser = Imetiers.LoginAdmin(a);
            if (monUser != null)
            {
                Session["UtilisateurId"] = monUser.UtilisateurId;
                Session["Nom"] = monUser.Nom;
                Session["Prenom"] = monUser.Prenom;
                Session["RoleId"] = monUser.RoleId;
                TempData["RoleAdmin"] = monUser.RoleId;
                return RedirectToAction("LoggedIn");

            }
            else
            {
                ModelState.AddModelError("", "user ou password incorrect");
                return View();
            }

        }
        public ActionResult Index()
        {

            if (Session["UtilisateurId"] != null)
            {
                ICollection<AdministrateurModele> res = Imetiers.findAllAdministrateurModele();
                return View(res);
            }
            else
                return View("Login");


          
        }

        // vue d' affichage du formulaire d'ajout des roles
        public ActionResult AjouterUnAdministrateur()
        {
            if (Session["RoleAdmin"] != null)
            {
                return View();
            }
            else
                return View("Login");
        }

        [HttpPost]
        public ActionResult AjouterUnAdministrateur(Administrateur unAdmin)
        {
            if (ModelState.IsValid)
            {
                Imetiers.AjouterUnAdministrateur(unAdmin);
                return RedirectToAction("Index");
            }

            else
            {
                return View(unAdmin);
            }
        }

        public ActionResult ModifierUnAdministrateur(int id)
        {

            if (Session["RoleAdmin"] != null)
            {

                Utilisateur monAdmin = Imetiers.findAdministrateur(id);

            return View(monAdmin);
            }
            else
                return View("Login");
        }

        [HttpPost]
        public ActionResult ModifierUnAdministrateur(Administrateur a)
        {

            Imetiers.ModifierUnAdministrateur(a);

            //a chaque fois qu on ajoute une categorie on la redirige vers l'action qui liste les elements
            return RedirectToAction("Index");
        }


        public ActionResult RechercherUnAdministrateur()
        {

            if (Session["RoleAdmin"] != null)
            {
                ICollection<Utilisateur> users = Imetiers.findAllAdministrateurs();
            return View(users);

            }
            else
                return View("Login");

        }

        [HttpPost]
        public ActionResult RechercherUnAdministrateur(int UtilisateurId)
        {

            ICollection<Utilisateur> product = Imetiers.findAdministrateurById(UtilisateurId);

            //a chaque fois qu on ajoute une categorie on la redirige vers l'action qui liste les elements
            return View(product);
        }

        public ActionResult SupprimerUnAdministrateur(int id)
        {
            if (Session["RoleAdmin"] != null)
            {
                Imetiers.SupprimerUnAdministrateur(id);
            return RedirectToAction("Index");
            }
            else
                return View("Login");
        }


      


        public ActionResult LoggedIn()
        {

            int role = (int)Session["RoleId"];
            if (role == (int)TempData["RoleAdmin"])
            {
                return View();
            }
            else
            {
                return RedirectToAction("Login");
            }

        }


        public ActionResult Logout()
        {
            Session["UtilisateurId"] = null;
            Session["Nom"] = null;
            Session["Prenom"] = null;
            Session["RoleId"] = null;
            return RedirectToAction("Login");
        }
    }
}