﻿using GestionMetiers.classesMetier;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionMetiers.ClassesDao
{
   public class EVentesDBcontext:DbContext
    {
        public DbSet<Utilisateur> Utilisateur                { get; set; }
        public DbSet<Catalogue>   Catalogue                  { get; set; }
        public DbSet<Produit>     Produit                    { get; set; }
        public DbSet<Adresse>     Adresse                    { get; set; }
        public DbSet<Commande>    Commande                   { get; set; }     
        public DbSet<ProduitsConsulte> ProduitConsulte       { get; set; }
        public DbSet<AvisProduit> AvisProduit                { get; set; }
        public DbSet<Panier> Panier                          { get; set; }  
        public DbSet<LigneDeCommande> LigneCommande          { get; set; }
        public DbSet<Paiement> Paiement                      { get; set; }
        public DbSet<Abonnement> Abonnement                  { get; set; }
        public DbSet<BonDeLivraison> BonDeLivraison          { get; set; }
    }
}

