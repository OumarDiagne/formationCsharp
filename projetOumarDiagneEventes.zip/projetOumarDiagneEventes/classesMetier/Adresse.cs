﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionMetiers.classesMetier
{
    public class Adresse
    {
        public int AdresseId { get; set; }
        public string NomDeRue { get; set; }
        public string CodePostal { get; set; }
        public string Ville { get; set; }
        public string Pays { get; set; }
        
        public  virtual ICollection<Utilisateur> Utilisateurs { get; set; }
    }
}
