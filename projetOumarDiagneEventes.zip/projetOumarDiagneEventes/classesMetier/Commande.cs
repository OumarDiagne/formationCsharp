﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionMetiers.classesMetier
{
   public class Commande                  //  1 vers 1
    {
        public int CommandeId { get; set; }
        public Enum EtatCommande { get; set; }
        public double facture { get; set; }
        public int UtilisateurId { get; set; }
        public virtual Client Clients { get; set; }

    }
}
