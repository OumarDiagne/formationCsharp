﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionMetiers.classesMetier
{
    public class Paiement
    {
        public int PaiementId { get; set; }
        public int numeroPaiement { get; set; }
        public int UtilisateurId { get; set; }
        public virtual Client  Client { get; set; }
    }
}
