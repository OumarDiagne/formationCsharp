﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionMetiers.classesMetier
{
   public  class Catalogue                        // 1 vers *, produit
    {
        public int catalogueId { get; set; }   
        public virtual ICollection<Produit> Produits { get; set; }



    }
}
