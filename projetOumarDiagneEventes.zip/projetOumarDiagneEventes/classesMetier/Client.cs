﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionMetiers.classesMetier
{
   public class Client: Utilisateur
    {

        public DateTime DateDeNaissance { get; set; }
        public string Email { get; set; }
        public Boolean Anniversaire { get; set; }
        public int NumeroCarteFidelite { get; set; }
        public int nbPoints { get; set; }
        public Boolean CompteActif { get; set; }
        public Boolean CompteASupprimer { get; set; }

        //relation 1 to many avec commande
        public virtual ICollection<Commande> Commandes { get; set; }
        public virtual ICollection<Paiement> MesPaiements { get; set; }
        public virtual ICollection<BonDeLivraison> MesBonsLivraison { get; set; }

        // collection d'abonnement

        public virtual ICollection<Abonnement> MesAbonnements { get; set; }


        //declaration pour la relation many to many, * vers * avec produit

        
        public virtual ICollection<ProduitsConsulte> ConsulteProduits { get; set; }
        public virtual ICollection<AvisProduit> AvisProduits { get; set; }


    }
}
