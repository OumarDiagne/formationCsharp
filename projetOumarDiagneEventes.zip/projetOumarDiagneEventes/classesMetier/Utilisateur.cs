﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionMetiers.classesMetier
{
   public  class Utilisateur
    {
        public int UtilisateurId { get; set; }
        public string Nom { get; set; }
        public string Prenom { get; set; }
        public string Identifiant { get; set; }
        public string Password { get; set; }
        public int    RoleId { get; set; }
        public int AdresseId { get; set; }
        public virtual Adresse Adresse { get; set; }




        //public string initConnexion() {
        //    return " entrez votre identifiant : " + identifiant + "\n entrez votre Mot de passe: " + password;
        //}

        //public string authentification()
        //{
        //    //initConnexion();
        //    //string str = "Data Source=localhost\\SQLExpress;Initial Catalog=BDDUtilisateurs; Integrated Security= TRUE";


        //    //// creation de notre dataadpater
        //    //SqlDataAdapter da = new SqlDataAdapter();

        //    ////commande à lire en base de donnees

        //    //da.SelectCommand = new SqlCommand("select * from Utilisateurs nom like @param ", new SqlConnection(str));
        //    //SqlParameter param = new SqlParameter("@param",identifiant);
        //    //da.SelectCommand.Parameters.Add(param);


        //    ////creation DataSet

        //    //DataSet ds = new DataSet();

        //    ////remplissage du DataSet avec les donnees et la structure de la base de donnee

        //    //da.Fill(ds, "personne");
        //    //if (ds.Tables[0].Select())


        //    //return "";

        //}  // fonction permettant l authentification 

    }
}
