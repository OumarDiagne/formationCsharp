﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionMetiers.classesMetier
{
  public class Panier        // relation 1 to many avec panier
    {
        public int          PanierId  { get; set; }
        public int          NbProduit { get; set; }
        public decimal      PrixTotal { get; set; }

        public virtual ICollection<LigneDeCommande> LigneDeMonPanier { get; set; }

    }
}
