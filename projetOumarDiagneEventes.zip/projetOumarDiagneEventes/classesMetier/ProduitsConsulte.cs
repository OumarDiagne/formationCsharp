﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionMetiers.classesMetier
{
   public class ProduitsConsulte   //table de jointure contient les id des deux objets client et produit
    {
        [Key,Column(Order =0)]   
        public int UtilisateurId { get; set; }
                                                               // relation manytomany avec produit et client
        [Key, Column(Order = 1)]
        public int ProduitId { get; set; }

        public virtual Client Client { get; set; }
        public virtual Produit Produit { get; set; }

        public DateTime DateConsultation { get; set; }
    }
}
