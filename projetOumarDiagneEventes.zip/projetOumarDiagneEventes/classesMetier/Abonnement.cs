﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionMetiers.classesMetier
{
   public class Abonnement            //relation 1 to many
    {
        public int AbonnementId { get; set; }
        public string Formule { get; set; }
        public DateTime DateSouscription { get; set; }
        public DateTime DateDeFin { get; set; }
        public decimal Tarif { get; set; }

        public int UtilisateurId { get; set; }
        public virtual Client Client { get; set; }

    }
}
