﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionMetiers.classesMetier
{
    public class Produit                     // * vers 1 , catalogue
    {
        //accesseurs

        public int ProduitId { get; set; }
        public string Nom { get; set; }
        public decimal Prix { get; set; }
        public string refProduit { get; set; }

        //declaration pour la relation many to 1, * vers 1
        public int CatalogueId { get; set; }
        public virtual Catalogue Catalogue { get; set; }

        //declaration pour la relation many to many, * vers * avec client
        

        public virtual ICollection<ProduitsConsulte> ProduitsConsulte { get; set; }
        public virtual ICollection<AvisProduit> ProduitsAvis { get; set; }

    }
}
