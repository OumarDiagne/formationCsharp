﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionMetiers.classesMetier
{
   public class LigneDeCommande            // relation manytomany avec lignes de commande entre produit et commande 
    {
        [Key, Column(Order = 0)]
        public int ProduitId { get; set; }

        [Key, Column(Order = 1)]
        public int CommandeId { get; set; }

        public int PanierId { get; set; }

        public virtual Panier Panier { get; set; }

        public virtual Produit Produit  { get; set; }
        public virtual Commande Commande { get; set; }

       
    }
}
